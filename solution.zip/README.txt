Angela Guo & Brady Bock

Angela: helper functions in_bounds, compute_index, clamp, get_r, get_g, get_b, get_a, test cases

Brady: helper functions blend_components, blend_colors, set_pixel, square, square_dist, all API functions, test cases